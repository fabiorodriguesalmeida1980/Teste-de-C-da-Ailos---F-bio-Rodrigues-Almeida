﻿namespace Questao1
{
    public class ContaBancaria {
        public ContaBancaria(int numero, string titular, double depositoInicial = 0)
        {
            this.Numero = numero;
            this.Titular = titular;
            this.DepositoInicial = depositoInicial;
        }

        public int Numero { get; set; }
        public string Titular { get; set; }
        public double DepositoInicial { get; set; }
       
        public double Deposito(double quantia, double depositoInicial = 0)
        {
            double totalConta = depositoInicial + quantia;

            return totalConta;
        }

        public double Saque(double quantia, double totalContaSaque)
        {
            double taxaSaque = 3.50;

            double totalConta = (totalContaSaque - quantia) - taxaSaque;

            return totalConta;
        }
    }
}