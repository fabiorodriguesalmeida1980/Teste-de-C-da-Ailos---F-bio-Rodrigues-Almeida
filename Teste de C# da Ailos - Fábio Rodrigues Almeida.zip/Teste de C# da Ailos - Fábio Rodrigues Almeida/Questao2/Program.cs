﻿using Newtonsoft.Json;
using Questao2;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

public class Program
{
    static HttpClient client = new HttpClient();

    static async Task Main()
    {
        int totalGoalsTeams1 = 0;
        int totalGoalsTeams2 = 0;

        // Entradas

        // Time 1 - Paris Saint-Germain
        // Ano - 2013

        // Time 2 - Chelsea
        // Ano - 2014

        Console.Write("Entre com o Time 1: ");
        string team1 = Console.ReadLine();

        Console.Write("Entre com o ano: ");
        int year1 = int.Parse(Console.ReadLine());

        Console.Write("Entre com o Time 2: ");
        string team2 = Console.ReadLine();

        Console.Write("Entre com o ano: ");
        int year2 = int.Parse(Console.ReadLine());

        var urlTeam1 = "https://localhost:7140/goalsScoredTeam?year=" + year1 + "&team1=" + team1;
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));

        var responseTeam1 = await client.GetAsync(urlTeam1);
        string contentTeam1 = await responseTeam1.Content.ReadAsStringAsync();

        var retornoFiltradoTeams1 = JsonConvert.DeserializeObject<GoalsScoredTeamResponse>(contentTeam1);

        if (retornoFiltradoTeams1 != null) {
            totalGoalsTeams1 = getTotalScoredGoals(retornoFiltradoTeams1);
        }

        Console.WriteLine("Team " + team1 + " scored " + totalGoalsTeams1 + " goals in " + year1);

        var urlTeam2 = "https://localhost:7140/goalsScoredTeam?year=" + year2 + "&team1=" + team2;
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));

        var responseTeam2 = await client.GetAsync(urlTeam2);
        string contentTeam2 = await responseTeam2.Content.ReadAsStringAsync();

        var retornoFiltradoTeams2 = JsonConvert.DeserializeObject<GoalsScoredTeamResponse>(contentTeam2);

        if (retornoFiltradoTeams2 != null)
        {
            totalGoalsTeams2 = getTotalScoredGoals(retornoFiltradoTeams2);
        }

        Console.WriteLine("Team " + team2 + " scored " + totalGoalsTeams2 + " goals in " + year2);

        //Output expected:
        // Team Paris Saint - Germain scored 109 goals in 2013
        // Team Chelsea scored 92 goals in 2014
    }

    public static int getTotalScoredGoals(GoalsScoredTeamResponse goalsScoredTeamResponse)
    {
        var somaGols = 0;

        foreach (var item in goalsScoredTeamResponse.data)
        {
            somaGols += Convert.ToInt32(item.team1goals);
        }

        return somaGols;
    }
}