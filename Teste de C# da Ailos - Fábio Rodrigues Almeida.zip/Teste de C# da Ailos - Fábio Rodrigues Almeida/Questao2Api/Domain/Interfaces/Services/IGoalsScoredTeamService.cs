﻿using Questao2Api.Domain.Entities;

namespace Questao2Api.Domain.Interfaces.Services
{
    public interface IGoalsScoredTeamService
    {
        GoalsScoredTeamResponse GetGoalsScoredTeam(int? year, string? team1, string? team2, int? page);
    }
}