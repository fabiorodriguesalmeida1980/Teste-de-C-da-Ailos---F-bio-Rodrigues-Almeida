﻿using Newtonsoft.Json;
using Questao2Api.Domain.Entities;
using Questao2Api.Domain.Interfaces.Repositories;

namespace Questao2Api.Infrastructure.Repositories
{
    public class GoalsScoredTeamRepository : IGoalsScoredTeamRepository
    {
        public GoalsScoredTeamResponse GetGoalsScoredTeam(int? year, string? team1, string? team2, int? page)
        {
            GoalsScoredTeamResponse retornoFiltrado = null;

            List<Datum> dataFiltrada = null;

            string mockRepository = @"{
  ""page"": 1,
  ""per_page"": 10,
  ""total"": 11581,
  ""total_pages"": 1159,
  ""data"": [
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""AC Milan"",
      ""team1goals"": ""20"",
      ""team2goals"": ""2""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""Real Madrid"",
      ""team1goals"": ""9"",
      ""team2goals"": ""4""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""Liverpool"",
      ""team1goals"": ""20"",
      ""team2goals"": ""1""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""Inter Milão"",
      ""team1goals"": ""20"",
      ""team2goals"": ""0""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""PSG"",
      ""team1goals"": ""20"",
      ""team2goals"": ""2""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""PSG"",
      ""team1goals"": ""20"",
      ""team2goals"": ""2""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupB"",
      ""team1"": ""APOEL Nikosia"",
      ""team2"": ""Zenit St. Petersburg"",
      ""team1goals"": ""10"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupC"",
      ""team1"": ""Borussia Dortmund"",
      ""team2"": ""Arsenal"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupD"",
      ""team1"": ""Viktoria Plzen"",
      ""team2"": ""BATE Borisov"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupE"",
      ""team1"": ""Chelsea"",
      ""team2"": ""Bayer Leverkusen"",
      ""team1goals"": ""2"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupF"",
      ""team1"": ""FC Porto"",
      ""team2"": ""Shakhtar Donetsk"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupG"",
      ""team1"": ""KRC Genk"",
      ""team2"": ""Valencia CF"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupH"",
      ""team1"": ""Olympiacos"",
      ""team2"": ""Olympique Marseille"",
      ""team1goals"": ""0"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupI"",
      ""team1"": ""AFC Ajax"",
      ""team2"": ""Olympique Lyon"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupJ"",
      ""team1"": ""Basel"",
      ""team2"": ""Otelul Galati"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""AC Milan"",
      ""team1goals"": ""4"",
      ""team2goals"": ""2""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""Real Madrid"",
      ""team1goals"": ""1"",
      ""team2goals"": ""4""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""Liverpool"",
      ""team1goals"": ""3"",
      ""team2goals"": ""1""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""Inter Milão"",
      ""team1goals"": ""2"",
      ""team2goals"": ""0""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""PSG"",
      ""team1goals"": ""5"",
      ""team2goals"": ""2""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupA"",
      ""team1"": ""Paris Saint-Germain"",
      ""team2"": ""PSG"",
      ""team1goals"": ""5"",
      ""team2goals"": ""2""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupB"",
      ""team1"": ""APOEL Nikosia"",
      ""team2"": ""Zenit St. Petersburg"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupC"",
      ""team1"": ""Borussia Dortmund"",
      ""team2"": ""Arsenal"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupD"",
      ""team1"": ""Viktoria Plzen"",
      ""team2"": ""BATE Borisov"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupE"",
      ""team1"": ""Chelsea"",
      ""team2"": ""Bayer Leverkusen"",
      ""team1goals"": ""2"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupF"",
      ""team1"": ""FC Porto"",
      ""team2"": ""Shakhtar Donetsk"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupG"",
      ""team1"": ""KRC Genk"",
      ""team2"": ""Valencia CF"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupH"",
      ""team1"": ""Olympiacos"",
      ""team2"": ""Olympique Marseille"",
      ""team1goals"": ""0"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupI"",
      ""team1"": ""AFC Ajax"",
      ""team2"": ""Olympique Lyon"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupJ"",
      ""team1"": ""Basel"",
      ""team2"": ""Otelul Galati"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupB"",
      ""team1"": ""APOEL Nikosia"",
      ""team2"": ""Zenit St. Petersburg"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupC"",
      ""team1"": ""Borussia Dortmund"",
      ""team2"": ""Arsenal"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupD"",
      ""team1"": ""Viktoria Plzen"",
      ""team2"": ""BATE Borisov"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupE"",
      ""team1"": ""Chelsea"",
      ""team2"": ""Bayer Leverkusen"",
      ""team1goals"": ""2"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupF"",
      ""team1"": ""FC Porto"",
      ""team2"": ""Shakhtar Donetsk"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupG"",
      ""team1"": ""KRC Genk"",
      ""team2"": ""Valencia CF"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupH"",
      ""team1"": ""Olympiacos"",
      ""team2"": ""Olympique Marseille"",
      ""team1goals"": ""0"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupI"",
      ""team1"": ""AFC Ajax"",
      ""team2"": ""Olympique Lyon"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2013,
      ""round"": ""GroupJ"",
      ""team1"": ""Basel"",
      ""team2"": ""Otelul Galati"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupA"",
      ""team1"": ""Chelsea"",
      ""team2"": ""AC Milan"",
      ""team1goals"": ""22"",
      ""team2goals"": ""2""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupA"",
      ""team1"": ""Chelsea"",
      ""team2"": ""Real Madrid"",
      ""team1goals"": ""20"",
      ""team2goals"": ""4""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupA"",
      ""team1"": ""Chelsea"",
      ""team2"": ""Liverpool"",
      ""team1goals"": ""10"",
      ""team2goals"": ""1""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupA"",
      ""team1"": ""Chelsea"",
      ""team2"": ""Inter Milão"",
      ""team1goals"": ""10"",
      ""team2goals"": ""0""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupA"",
      ""team1"": ""Chelsea"",
      ""team2"": ""PSG"",
      ""team1goals"": ""10"",
      ""team2goals"": ""2""
    },
	{
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupA"",
      ""team1"": ""Chelsea"",
      ""team2"": ""PSG"",
      ""team1goals"": ""20"",
      ""team2goals"": ""2""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupB"",
      ""team1"": ""APOEL Nikosia"",
      ""team2"": ""Zenit St. Petersburg"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupC"",
      ""team1"": ""Borussia Dortmund"",
      ""team2"": ""Arsenal"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2012,
      ""round"": ""GroupD"",
      ""team1"": ""Viktoria Plzen"",
      ""team2"": ""BATE Borisov"",
      ""team1goals"": ""1"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupF"",
      ""team1"": ""FC Porto"",
      ""team2"": ""Shakhtar Donetsk"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupG"",
      ""team1"": ""KRC Genk"",
      ""team2"": ""Valencia CF"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupH"",
      ""team1"": ""Olympiacos"",
      ""team2"": ""Olympique Marseille"",
      ""team1goals"": ""0"",
      ""team2goals"": ""1""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupI"",
      ""team1"": ""AFC Ajax"",
      ""team2"": ""Olympique Lyon"",
      ""team1goals"": ""0"",
      ""team2goals"": ""0""
    },
    {
      ""competition"": ""UEFA Champions League"",
      ""year"": 2014,
      ""round"": ""GroupJ"",
      ""team1"": ""Basel"",
      ""team2"": ""Otelul Galati"",
      ""team1goals"": ""2"",
      ""team2goals"": ""1""
    }
  ]
}";

            retornoFiltrado = JsonConvert.DeserializeObject<GoalsScoredTeamResponse>(mockRepository);

            if (year != null && team1 != null && team2 != null)
            {
                retornoFiltrado.data = retornoFiltrado.data.Where(x => x.year == year && x.team1 == team1 && x.team2 == team2).ToList();
            }
            else if (year != null && team1 != null)
            {
                retornoFiltrado.data = retornoFiltrado.data.Where(x => x.year == year && x.team1 == team1).ToList();
            }
            else if (year != null && team2 != null)
            {
                retornoFiltrado.data = retornoFiltrado.data.Where(x => x.year == year && x.team2 == team2).ToList();
            }
            else if (team1 != null && team2 != null)
            {
                retornoFiltrado.data = retornoFiltrado.data.Where(x => x.team1 == team1 && x.team2 == team2).ToList();
            }
            else if (year != null)
            {
                retornoFiltrado.data = retornoFiltrado.data.Where(x => x.year == year).ToList();
            }
            else if (team1 != null)
            {
                retornoFiltrado.data = retornoFiltrado.data.Where(x => x.team1 == team1).ToList();
            }
            else if (team2 != null)
            {
                retornoFiltrado.data = retornoFiltrado.data.Where(x => x.team2 == team2).ToList();
            }
            else if (page != null)
            {
                retornoFiltrado.page = (int)page;
            }

            retornoFiltrado.total_pages = retornoFiltrado.data.Count();
            retornoFiltrado.total = retornoFiltrado.data.Count();

            return retornoFiltrado;
        }
    }
}