using Microsoft.AspNetCore.Mvc;
using Questao2Api.Domain.Entities;
using Questao2Api.Domain.Interfaces.Services;
using Xunit.Sdk;

namespace Questao2Api.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("goalsScoredTeam")]
    [ApiVersion("1.0")]
    [Produces("application/json")]
    public class GoalsScoredTeamController : ControllerBase
    {
        #region Privates
        
        private readonly ILogger<GoalsScoredTeamController> _logger;
        private readonly IGoalsScoredTeamService _goalsScoredTeamService;

        #endregion

        #region Constructors

        public GoalsScoredTeamController(ILogger<GoalsScoredTeamController> logger, IGoalsScoredTeamService goalsScoredTeamService)
        {
            _logger = logger;
            _goalsScoredTeamService = goalsScoredTeamService;
        }

        #endregion

        /// <summary>
        /// Gols Marcados dos Times no Ano
        /// </summary>
        /// <returns></returns>
        [ActionName(nameof(GetGoalsScoredTeam))]
        [HttpGet]
        [ProducesResponseType(typeof(List<GoalsScoredTeamResponse>), 200)]
        [ProducesResponseType(typeof(StatusCodes), 204)]
        [ProducesResponseType(typeof(StatusCodes), 400)]
        [ProducesResponseType(typeof(StatusCodes), 401)]
        [ProducesResponseType(typeof(StatusCodes), 403)]
        [ProducesResponseType(typeof(ErrorMessage), 500)]
        public IActionResult GetGoalsScoredTeam([FromQuery] int? year, string? team1, string? team2, int? page)
        {
            var result = _goalsScoredTeamService.GetGoalsScoredTeam(year, team1, team2, page);

            if (result.data.Count == 0) {
                return NoContent();
            }

            return Ok(result);
        }
    }
}