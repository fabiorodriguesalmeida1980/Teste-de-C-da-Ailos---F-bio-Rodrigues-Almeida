﻿using Questao2Api.Domain.Entities;
using Questao2Api.Domain.Interfaces.Repositories;
using Questao2Api.Domain.Interfaces.Services;

namespace Questao2Api.Infrastructure.Services
{
    public class GoalsScoredTeamService : IGoalsScoredTeamService
    {
        #region Privates

        private readonly IGoalsScoredTeamRepository _goalsScoredTeamRepository;

        #endregion

        #region Constructor

        public GoalsScoredTeamService(
            IGoalsScoredTeamRepository goalsScoredTeamRepository
            )
        {
            _goalsScoredTeamRepository = goalsScoredTeamRepository;
        }

        #endregion

        GoalsScoredTeamResponse IGoalsScoredTeamService.GetGoalsScoredTeam(int? year, string? team1, string? team2, int? page)
        {
            return _goalsScoredTeamRepository.GetGoalsScoredTeam(year, team1, team2, page);
        }
    }
}