using MediatR;
using Questao2Api.Domain.Interfaces.Repositories;
using Questao2Api.Domain.Interfaces.Services;
using Questao2Api.Infrastructure.Repositories;
using Questao2Api.Infrastructure.Services;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddTransient<IGoalsScoredTeamService, GoalsScoredTeamService>();
builder.Services.AddTransient<IGoalsScoredTeamRepository, GoalsScoredTeamRepository>();
builder.Services.AddControllers();
builder.Services.AddMediatR(Assembly.GetExecutingAssembly());
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();