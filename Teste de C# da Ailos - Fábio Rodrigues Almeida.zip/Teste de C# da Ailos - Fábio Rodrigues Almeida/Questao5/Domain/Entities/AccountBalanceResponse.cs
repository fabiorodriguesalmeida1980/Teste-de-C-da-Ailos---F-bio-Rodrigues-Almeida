﻿namespace Questao5.Domain.Entities
{
    public class AccountBalanceResponse
    {
        public int NumeroConta { get; set; }
        public string NomeTitular { get; set; }
        public string TipoMovimento { get; set; }
        public string DataHoraResposta { get; set; }
        public string SaldoAtualConta { get; set; }
        public string MensagemErro { get; set; }
    }
}