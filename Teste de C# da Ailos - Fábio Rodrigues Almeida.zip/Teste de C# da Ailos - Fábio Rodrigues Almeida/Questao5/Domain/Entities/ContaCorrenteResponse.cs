﻿namespace Questao5.Domain.Entities
{
    public class ContaCorrenteResponse
    {
        public string IdContaCorrente { get; set; }
        public int Numero { get; set; }
        public string Nome { get; set; }
        public int Ativo { get; set; }
        public string MensagemErro { get; set; }
    }
}