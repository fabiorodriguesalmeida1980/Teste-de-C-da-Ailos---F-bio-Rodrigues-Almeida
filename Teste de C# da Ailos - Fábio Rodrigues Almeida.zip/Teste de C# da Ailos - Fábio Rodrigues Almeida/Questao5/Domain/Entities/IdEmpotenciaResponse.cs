﻿namespace Questao5.Domain.Entities
{
    public class IdEmpotenciaResponse
    {
        public string ChaveIdEmpotencia { get; set; }
        public string Requisicao { get; set; }
        public string Resultado { get; set; }
        public string MensagemErro { get; set; }
    }
}