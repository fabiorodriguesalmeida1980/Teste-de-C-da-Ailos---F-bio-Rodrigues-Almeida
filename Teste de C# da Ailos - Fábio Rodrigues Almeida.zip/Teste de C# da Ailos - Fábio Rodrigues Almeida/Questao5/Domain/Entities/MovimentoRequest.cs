﻿namespace Questao5.Domain.Entities
{
    public class MovimentoRequest
    {
        public string idContaCorrente { get; set; }
        public string dataMovimento { get; set; }
        public string tipoMovimento { get; set; }
        public double valor { get; set; }
    }
}