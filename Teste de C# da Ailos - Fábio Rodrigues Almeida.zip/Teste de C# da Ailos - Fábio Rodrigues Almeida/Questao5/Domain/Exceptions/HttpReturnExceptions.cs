﻿namespace Questao5.Domain.Exceptions
{
    public class HttpReturnException : Exception
    {
        public int StatusCode { get; set; }
        public object Body { get; set; }

        public HttpReturnException(int statusCode, object Body) 
        {
            StatusCode = statusCode;
            Body = Body;
        }
    }
}