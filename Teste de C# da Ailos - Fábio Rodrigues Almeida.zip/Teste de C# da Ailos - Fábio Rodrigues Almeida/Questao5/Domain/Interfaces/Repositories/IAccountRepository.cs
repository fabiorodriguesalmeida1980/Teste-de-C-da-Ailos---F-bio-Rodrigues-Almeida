﻿using Questao5.Domain.Entities;

namespace Questao5.Domain.Interfaces.Repositories
{
    public interface IAccountRepository
    {
        Task<List<ContaCorrenteResponse>> SearchAccount(string idContaCorrente, string tipoMovimento);
        Task<List<AccountBalanceResponse>> GetAccountBalance(string idContaCorrente, string tipoMovimento);
        Task<List<IdEmpotenciaResponse>> SearchIdEmpotencia(string idContaCorrente);
        Task<List<MovimentoResponse>> PostAccountMovement(MovimentoRequest movimentoRequest, string idEmpotenciaResultado);
    }
}