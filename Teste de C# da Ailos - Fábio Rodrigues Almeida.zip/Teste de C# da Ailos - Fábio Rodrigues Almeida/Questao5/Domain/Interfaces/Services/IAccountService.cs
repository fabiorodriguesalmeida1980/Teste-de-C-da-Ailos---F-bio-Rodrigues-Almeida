﻿using Questao5.Domain.Entities;

namespace Questao5.Domain.Interfaces.Services
{
    public interface IAccountService
    {
        Task<List<ContaCorrenteResponse>> SearchAccount(string idContaCorrente, string tipoMovimento);
        Task<List<AccountBalanceResponse>> GetAccountBalance(string idContaCorrente, string tipoMovimento);
        Task<List<IdEmpotenciaResponse>> SearchIdEmpotencia(string idContaCorrente);
        Task<List<MovimentoResponse>> PostAccountMovement(MovimentoRequest movimentoRequest, string idEmpotenciaResultado);
    }
}