﻿using Microsoft.Data.Sqlite;
using Questao5.Domain.Entities;
using Questao5.Domain.Interfaces.Repositories;
using Questao5.Infrastructure.Sqlite;
using System.Collections.Generic;
using System.Globalization;

namespace Questao5.Infrastructure.Repositories
{
    public class AccountRepository : IAccountRepository
    {
        private readonly DatabaseConfig _databaseConfig;

        public AccountRepository(DatabaseConfig databaseConfig)
        {
            _databaseConfig = databaseConfig;
        }

        public List<ContaCorrenteResponse> ConsultarContaCorrente(string idContaCorrente, string tipoMovimento)
        {
            string querySelect = "SELECT * FROM contacorrente WHERE idcontacorrente = " + '"' + idContaCorrente + '"';

            List<ContaCorrenteResponse> _contaCorrenteList = new List<ContaCorrenteResponse>();

            using (SqliteConnection connection = new SqliteConnection(_databaseConfig.Name))
            {
                try
                {
                    connection.Open();
                    using (SqliteCommand command = new SqliteCommand(querySelect, connection))
                    {
                        using (SqliteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _contaCorrenteList.Add(new ContaCorrenteResponse()
                                {
                                    IdContaCorrente = reader["idcontacorrente"].ToString(),
                                    Numero = Convert.ToInt32(reader["numero"]),
                                    Nome = reader["nome"].ToString(),
                                    Ativo = Convert.ToInt32(reader["ativo"])
                                });
                            }
                        }
                    }
                    connection.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                }
            }

            if (_contaCorrenteList.Count() > 0)
            {
                var consultaAtivo = _contaCorrenteList.Select(x => x.Ativo).FirstOrDefault();

                if (consultaAtivo == 0)
                {
                    foreach (var item in _contaCorrenteList)
                    {
                        item.MensagemErro = tipoMovimento != "" ? "TIPO: INACTIVE_ACCOUNT. Apenas contas correntes ativas podem receber movimentação." : "TIPO: INACTIVE_ACCOUNT. Apenas contas correntes ativas podem consultar o saldo.";
                    }
                }
                else
                {
                    _contaCorrenteList = _contaCorrenteList.Where(x => x.Ativo == 1).ToList();
                }
            }
            else
            {
                _contaCorrenteList.Add(new ContaCorrenteResponse()
                {
                    Numero = 0,
                    MensagemErro = tipoMovimento != "" ? "TIPO: INVALID_ACCOUNT. Apenas contas correntes cadastradas podem receber movimentação." : "TIPO: INVALID_ACCOUNT. Apenas contas correntes cadastradas podem consultar o saldo."
                });
            }

            return _contaCorrenteList;
        }

        public List<AccountBalanceResponse> SaldoContaCorrente(string idContaCorrente, string tipoMovimento)
        {
            // Crédito
            string querySaldoContaCredito = "select C.numero, C.nome, M.tipomovimento, (SELECT SUM(valor) FROM movimento Where tipomovimento = 'C') as saldo from contacorrente as C " +
                "Inner Join movimento as M ON M.idcontacorrente = C.idcontacorrente Where C.idcontacorrente = " + '"' + idContaCorrente + '"' + " " +
                "And C.ativo = 1 and M.tipomovimento = 'C' Group By C.numero, C.nome";


            // Débito
            //string querySaldoContaDebito = "select C.numero, C.nome, M.tipomovimento, (SELECT SUM(valor) FROM movimento Where tipomovimento = 'D') as saldo from contacorrente as C " +
            //    "Inner Join movimento as M ON M.idcontacorrente = C.idcontacorrente Where C.idcontacorrente = " + '"' + idContaCorrente + '"' + " " +
            //    "And C.ativo = 1 and M.tipomovimento = 'D' Group By C.numero, C.nome";

            //string querySaldoConta = "select C.numero, C.nome, (SELECT SUM(valor) FROM movimento Where tipomovimento = 'C' " +
            //    "And idcontacorrente = " + '"' + idContaCorrente + '"' + ") - (SELECT SUM(valor) FROM movimento Where tipomovimento = 'D' " +
            //    "And idcontacorrente = " + '"' + idContaCorrente + '"' + ") as saldo from contacorrente as C " +
            //    "Inner Join movimento as M ON M.idcontacorrente = C.idcontacorrente Where C.idcontacorrente = " + '"' + idContaCorrente + '"' + " " +
            //    "And C.ativo = 1 Group By C.numero, C.nome";

            List<AccountBalanceResponse> _saldoContaCorrenteList = new List<AccountBalanceResponse>();

            List<AccountBalanceResponse> _saldoContaCorrenteListCredito = new List<AccountBalanceResponse>();
            
            using (SqliteConnection connection = new SqliteConnection(_databaseConfig.Name))
            {
                try
                {
                    connection.Open();
                    using (SqliteCommand command = new SqliteCommand(querySaldoContaCredito, connection))
                    {
                        using (SqliteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _saldoContaCorrenteList.Add(new AccountBalanceResponse()
                                {
                                    NumeroConta = Convert.ToInt32(reader["numero"]),
                                    NomeTitular = reader["nome"].ToString(),
                                    TipoMovimento = reader["tipomovimento"].ToString(),
                                    DataHoraResposta = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture),
                                    SaldoAtualConta = Convert.ToDouble(reader["saldo"]).ToString("F2", CultureInfo.InvariantCulture)
                                });
                            }
                        }
                    }
                    connection.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                }
            }

            if (_saldoContaCorrenteList.Count() > 0)
            {
                foreach (var item in _saldoContaCorrenteList)
                {
                    AccountBalanceResponse accountBalanceResponseCredito = new AccountBalanceResponse();

                    accountBalanceResponseCredito.NumeroConta = item.NumeroConta;
                    accountBalanceResponseCredito.NomeTitular = item.NomeTitular;
                    accountBalanceResponseCredito.TipoMovimento = item.TipoMovimento;
                    accountBalanceResponseCredito.DataHoraResposta = item.DataHoraResposta;
                    accountBalanceResponseCredito.SaldoAtualConta = item.SaldoAtualConta;

                    _saldoContaCorrenteListCredito.Add(accountBalanceResponseCredito);

                    _saldoContaCorrenteList = null;
                }

                // Débito
                string querySaldoContaDebito = "select C.numero, C.nome, M.tipomovimento, (SELECT SUM(valor) FROM movimento Where tipomovimento = 'D') as saldo from contacorrente as C " +
                    "Inner Join movimento as M ON M.idcontacorrente = C.idcontacorrente Where C.idcontacorrente = " + '"' + idContaCorrente + '"' + " " +
                    "And C.ativo = 1 and M.tipomovimento = 'D' Group By C.numero, C.nome";

                List<AccountBalanceResponse> _saldoContaCorrenteListDebito = new List<AccountBalanceResponse>();
                List<AccountBalanceResponse> _saldoContaCorrenteListD = new List<AccountBalanceResponse>();

                using (SqliteConnection connectionD = new SqliteConnection(_databaseConfig.Name))
                {
                    try
                    {
                        connectionD.Open();
                        using (SqliteCommand command = new SqliteCommand(querySaldoContaDebito, connectionD))
                        {
                            using (SqliteDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    _saldoContaCorrenteListD.Add(new AccountBalanceResponse()
                                    {
                                        NumeroConta = Convert.ToInt32(reader["numero"]),
                                        NomeTitular = reader["nome"].ToString(),
                                        TipoMovimento = reader["tipomovimento"].ToString(),
                                        DataHoraResposta = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture),
                                        SaldoAtualConta = Convert.ToDouble(reader["saldo"]).ToString("F2", CultureInfo.InvariantCulture)
                                    });
                                }
                            }
                        }
                        connectionD.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                    }
                }

                if (_saldoContaCorrenteListD != null)
                {
                    foreach (var item in _saldoContaCorrenteListD)
                    {
                        AccountBalanceResponse accountBalanceResponseDebito = new AccountBalanceResponse();

                        accountBalanceResponseDebito.NumeroConta = item.NumeroConta;
                        accountBalanceResponseDebito.NomeTitular = item.NomeTitular;
                        accountBalanceResponseDebito.TipoMovimento = item.TipoMovimento;
                        accountBalanceResponseDebito.DataHoraResposta = item.DataHoraResposta;
                        accountBalanceResponseDebito.SaldoAtualConta = item.SaldoAtualConta;

                        _saldoContaCorrenteListDebito.Add(accountBalanceResponseDebito);

                        _saldoContaCorrenteListD = null;
                    }
                }

                var retornoListaCredito = _saldoContaCorrenteListCredito;
                var retornoListaDebito = _saldoContaCorrenteListDebito;

                var somaTotalCredito = retornoListaCredito.Select(x => x.SaldoAtualConta).FirstOrDefault();
                var somaTotalDebito = retornoListaDebito.Select(x => x.SaldoAtualConta).FirstOrDefault();

                if (retornoListaCredito.Count == 0)
                {
                    _saldoContaCorrenteList.Add(new AccountBalanceResponse()
                    {
                        SaldoAtualConta = "0",
                        MensagemErro = "TIPO: INVALID_VALUE. Apenas valores positivos podem ser recebidos."
                    });
                }

                if (retornoListaCredito.Count > 0 && retornoListaDebito.Count == 0)
                {
                    _saldoContaCorrenteList = retornoListaCredito;
                }

                if (Convert.ToDouble(somaTotalCredito) >= Convert.ToDouble(somaTotalDebito))
                {
                    _saldoContaCorrenteList = retornoListaCredito;

                    var num1 = Convert.ToDecimal(somaTotalCredito.Replace(".", ","));
                    var num2 = Convert.ToDecimal(somaTotalDebito.Replace(".", ","));

                    decimal TotalConta = num1 - num2;

                    foreach (var item in _saldoContaCorrenteList)
                    {
                        item.SaldoAtualConta = "0";
                        item.SaldoAtualConta = TotalConta.ToString().Replace(",",".");
                    }
                }
            }
            
            return _saldoContaCorrenteList;
        }

        public List<IdEmpotenciaResponse> ConsultaIdEmpotencia(string idContaCorrente)
        {
            string querySelect = "SELECT * FROM idempotencia WHERE chave_idempotencia = " + '"' + idContaCorrente + '"';

            List<IdEmpotenciaResponse> _idEmpotenciaList = new List<IdEmpotenciaResponse>();

            using (SqliteConnection connection = new SqliteConnection(_databaseConfig.Name))
            {
                try
                {
                    connection.Open();
                    using (SqliteCommand command = new SqliteCommand(querySelect, connection))
                    {
                        using (SqliteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _idEmpotenciaList.Add(new IdEmpotenciaResponse()
                                {
                                    ChaveIdEmpotencia = reader["chave_idempotencia"].ToString(),
                                    Requisicao = reader["requisicao"].ToString(),
                                    Resultado = reader["resultado"].ToString()
                                });
                            }
                        }
                    }
                    connection.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                }
            }

            if (_idEmpotenciaList.Count() > 0)
            {
                foreach (var item in _idEmpotenciaList)
                {
                    item.MensagemErro = "Atenção! Essa movimentação já foi processada com sucesso.";
                }

                //_idEmpotenciaList.Add(new IdEmpotenciaResponse()
                //{
                //    ChaveIdEmpotencia = _idEmpotenciaList[0].ChaveIdEmpotencia,
                //    MensagemErro = ""
                //});
            }

            return _idEmpotenciaList;
        }

        public List<MovimentoResponse> ConsultarMovimentacao(MovimentoRequest movimentoRequest)
        {
            string querySelect = "SELECT * FROM movimento WHERE idcontacorrente = " + '"' + movimentoRequest.idContaCorrente + '"';

            List<MovimentoResponse> _movimentoList = new List<MovimentoResponse>();

            using (SqliteConnection connection = new SqliteConnection(_databaseConfig.Name))
            {
                try
                {
                    connection.Open();
                    using (SqliteCommand command = new SqliteCommand(querySelect, connection))
                    {
                        using (SqliteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _movimentoList.Add(new MovimentoResponse()
                                {
                                    IdMovimento = reader["idmovimento"].ToString(),
                                    IdContaCorrente = reader["idcontacorrente"].ToString(),
                                    DataMovimento = Convert.ToDateTime(reader["datamovimento"]).ToString("dd/MM/yyyy"),
                                    TipoMovimento = reader["tipomovimento"].ToString(),
                                    Valor = Convert.ToDouble(reader["valor"]).ToString("F2", CultureInfo.InvariantCulture)
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                }
                finally
                {
                    connection.Close();
                }
            }

            return _movimentoList;
        }

        public List<MovimentoResponse> InserirMovimentacao(MovimentoRequest movimentoRequest)
        {
            var queryInsert = "INSERT INTO movimento (idmovimento, idcontacorrente, datamovimento, tipomovimento, valor) " +
            "VALUES (@idmovimento, @idcontacorrente, @datamovimento, @tipomovimento, @valor)";

            DateTime dataMovimentacao = Convert.ToDateTime(movimentoRequest.dataMovimento);
            string dataMovimentacaoFormatada = dataMovimentacao.ToString("yyyy-MM-dd");

            var idmovimento = Guid.NewGuid().ToString().ToUpper();
            var idcontacorrente = movimentoRequest.idContaCorrente.ToUpper();
            var datamovimento = dataMovimentacaoFormatada;
            var tipomovimento = movimentoRequest.tipoMovimento;
            var valor = movimentoRequest.valor;

            using (SqliteConnection connection = new SqliteConnection(_databaseConfig.Name))
            {
                try
                {
                    connection.Open();
                    using (SqliteCommand command = new SqliteCommand(queryInsert, connection))
                    {
                        command.Parameters.AddWithValue("@idmovimento", idmovimento);
                        command.Parameters.AddWithValue("@idcontacorrente", idcontacorrente);
                        command.Parameters.AddWithValue("@datamovimento", datamovimento);
                        command.Parameters.AddWithValue("@tipomovimento", tipomovimento);
                        command.Parameters.AddWithValue("@valor", valor);

                        var rowInserted = command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                }
                finally
                {
                    connection.Close();
                }
            }

            var retornoConsulta = ConsultarMovimentacao(movimentoRequest);

            return retornoConsulta;
        }

        public List<IdEmpotenciaResponse> InserirIdEmpotencia(string idContaCorrente, string requisicao, string resultadoInserir)
        {
            var queryInsert = "INSERT INTO idempotencia (chave_idempotencia, requisicao, resultado) " +
            "VALUES (@chave_idempotencia, @requisicao, @resultado)";

            //var idmovimento = Guid.NewGuid().ToString().ToUpper();
            var chave_idempotencia = idContaCorrente;
            var requisicaoExecutada = requisicao;
            var resultadoRequisicao = resultadoInserir;

            using (SqliteConnection connection = new SqliteConnection(_databaseConfig.Name))
            {
                try
                {
                    connection.Open();
                    using (SqliteCommand command = new SqliteCommand(queryInsert, connection))
                    {
                        command.Parameters.AddWithValue("@chave_idempotencia", chave_idempotencia);
                        command.Parameters.AddWithValue("@requisicao", requisicaoExecutada);
                        command.Parameters.AddWithValue("@resultado", resultadoRequisicao);

                        var rowInserted = command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                }
                finally
                {
                    connection.Close();
                }
            }

            var retornoConsulta = ConsultaIdEmpotencia(chave_idempotencia);

            return retornoConsulta;
        }

        public List<IdEmpotenciaResponse> AtualizarIdEmpotencia(string idContaCorrente)
        {
            var queryAtualizar = "Update idempotencia set resultado = @resultado Where chave_idempotencia = @chave_idempotencia";

            var chaveIdEmpotencia = idContaCorrente;
            var resultadoSucesso = "Sucesso";

            using (SqliteConnection connection = new SqliteConnection(_databaseConfig.Name))
            {
                try
                {
                    connection.Open();
                    using (SqliteCommand command = new SqliteCommand(queryAtualizar, connection))
                    {
                        command.Parameters.AddWithValue("@chave_idempotencia", chaveIdEmpotencia);
                        command.Parameters.AddWithValue("@resultado", resultadoSucesso);

                        var rowUpdate = command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ler dados: {ex.Message}");
                }
                finally
                {
                    connection.Close();
                }
            }

            var retornoConsulta = ConsultaIdEmpotencia(chaveIdEmpotencia);

            return retornoConsulta;
        }

        public async Task<List<ContaCorrenteResponse>> SearchAccount(string idContaCorrente, string tipoMovimento)
        {
            var consultaContaCorrente = ConsultarContaCorrente(idContaCorrente, tipoMovimento);

            return consultaContaCorrente;
        }

        public async Task<List<AccountBalanceResponse>> GetAccountBalance(string idContaCorrente, string tipoMovimento)
        {
            var saldoContaCorrente = SaldoContaCorrente(idContaCorrente, tipoMovimento);

            return saldoContaCorrente;
        }

        public async Task<List<IdEmpotenciaResponse>> SearchIdEmpotencia(string idContaCorrente)
        {
            var searchIdEmpotencia = ConsultaIdEmpotencia(idContaCorrente);

            return searchIdEmpotencia;
        }

        public async Task<List<MovimentoResponse>> PostAccountMovement(MovimentoRequest movimentoRequest, string idEmpotenciaResultado)
        {
            var retornoMovimentacao = InserirMovimentacao(movimentoRequest);

            var retornoInsercao = retornoMovimentacao.FirstOrDefault();

            if (retornoInsercao.IdMovimento == "" && retornoInsercao.IdContaCorrente == "")
            {
                var requisicao = "InserirMovimentacao";
                var resultadoInserir = "FalhaConexaoApi";
                var retornoInsercaoIdEmpotencia = InserirIdEmpotencia(movimentoRequest.idContaCorrente, requisicao, resultadoInserir);
            }

            if (idEmpotenciaResultado == "FALHACONEXAOAPI")
            {
                var retornoAtualizarIdEmpotencia = AtualizarIdEmpotencia(movimentoRequest.idContaCorrente);
            }

            return retornoMovimentacao;
        }
    }
}