﻿using Questao5.Domain.Entities;
using Questao5.Domain.Interfaces.Repositories;
using Questao5.Domain.Interfaces.Services;

namespace Questao5.Infrastructure.Services
{
    public class AccountService : IAccountService
    {
        #region Privates

        private readonly IAccountRepository _accountRepository;

        #endregion

        #region Constructor

        public AccountService(
            IAccountRepository accountRepository
            )
        {
            _accountRepository = accountRepository;
        }

        public async Task<List<ContaCorrenteResponse>> SearchAccount(string idContaCorrente, string tipoMovimento)
        {
            return await _accountRepository.SearchAccount(idContaCorrente, tipoMovimento);
        }

        public async Task<List<AccountBalanceResponse>> GetAccountBalance(string idContaCorrente, string tipoMovimento)
        {
            return await _accountRepository.GetAccountBalance(idContaCorrente, "");
        }

        public async Task<List<IdEmpotenciaResponse>> SearchIdEmpotencia(string idContaCorrente)
        {
            return await _accountRepository.SearchIdEmpotencia(idContaCorrente);
        }

        public async Task<List<MovimentoResponse>> PostAccountMovement(MovimentoRequest movimentoRequest, string idEmpotenciaResultado)
        {
            return await _accountRepository.PostAccountMovement(movimentoRequest, idEmpotenciaResultado);
        }

        #endregion
    }
}