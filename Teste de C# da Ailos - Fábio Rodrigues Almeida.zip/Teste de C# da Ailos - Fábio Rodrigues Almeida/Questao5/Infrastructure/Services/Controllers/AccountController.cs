using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Questao5.Domain.Entities;
using Questao5.Domain.Interfaces.Services;
using System.Collections.Generic;
using Xunit.Sdk;

namespace Questao5.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("account")]
    [Produces("application/json")]
    public class AccountController : ControllerBase
    {
        #region Privates

        private readonly ILogger<AccountController> _logger;
        private readonly IAccountService _accountService;

        #endregion

        #region Constructors

        public AccountController(ILogger<AccountController> logger, IAccountService accountService)
        {
            _logger = logger;
            _accountService = accountService;
        }

        #endregion

        /// <summary>
        /// Movimenta��o de uma conta corrente
        /// </summary>
        /// <returns></returns>
        [ActionName(nameof(PostAccountMovement))]
        [HttpPost("movimento")]
        [ProducesResponseType(typeof(MovimentoResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ErrorMessage), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> PostAccountMovement([FromBody] MovimentoRequest movimentoRequest)
        {
            List<MovimentoResponse> result = null;

            if (movimentoRequest.tipoMovimento.Length > 1)
            {
                movimentoRequest.tipoMovimento = movimentoRequest.tipoMovimento.Substring(0, 1).ToUpper();
            }

            if (movimentoRequest.tipoMovimento != "D" && movimentoRequest.tipoMovimento != "C")
            {
                _logger.LogError("TIPO: INVALID_TYPE. Aten��o! Apenas os tipos D�bito (D) ou Cr�dito (C) s�o de aceitos.");
                return BadRequest("TIPO: INVALID_TYPE. Aten��o! Apenas os tipos D�bito (D) ou Cr�dito (C) s�o de aceitos.");
            }

            if (movimentoRequest.valor > 0)
            {
                var resultContaCorrente = await _accountService.SearchAccount(movimentoRequest.idContaCorrente, movimentoRequest.tipoMovimento);

                var returnCC = resultContaCorrente.FirstOrDefault();

                if (returnCC.Numero == 0)
                {
                    _logger.LogError(returnCC.MensagemErro);
                    return BadRequest(returnCC.MensagemErro);
                }

                if (returnCC.Numero > 0 && returnCC.Ativo == 0)
                {
                    _logger.LogError(returnCC.MensagemErro);
                    return BadRequest(returnCC.MensagemErro);
                }

                var searchIdEmpotencia = await _accountService.SearchIdEmpotencia(movimentoRequest.idContaCorrente);

                var returnIdEmpotencia = searchIdEmpotencia.FirstOrDefault();

                if (returnIdEmpotencia == null || returnIdEmpotencia.Resultado.ToUpper() == "FALHACONEXAOAPI" || returnIdEmpotencia.Resultado.ToUpper() == "SUCESSO")
                {
                    if (returnIdEmpotencia == null || returnIdEmpotencia.Resultado.ToUpper() == "SUCESSO")
                    {
                        result = await _accountService.PostAccountMovement(movimentoRequest, "");
                    }
                    else
                    {
                        result = await _accountService.PostAccountMovement(movimentoRequest, returnIdEmpotencia.Resultado.ToUpper());
                    }
                    
                    return Ok(result);
                }
                else
                {
                    _logger.LogError(returnIdEmpotencia.MensagemErro);
                    return BadRequest(returnIdEmpotencia.MensagemErro);
                }
            }
            else
            {
                _logger.LogError("TIPO: INVALID_VALUE. Apenas valores positivos podem ser recebidos.");
                return BadRequest("TIPO: INVALID_VALUE. Apenas valores positivos podem ser recebidos.");
            }
        }

        /// <summary>
        /// Consulta Saldo da Conta Corrente
        /// </summary>
        /// <returns></returns>
        [ActionName(nameof(GetAccountBalance))]
        [HttpGet("balance")]
        [ProducesResponseType(typeof(List<AccountBalanceResponse>), 200)]
        [ProducesResponseType(typeof(StatusCodes), 204)]
        [ProducesResponseType(typeof(StatusCodes), 400)]
        [ProducesResponseType(typeof(StatusCodes), 401)]
        [ProducesResponseType(typeof(StatusCodes), 403)]
        [ProducesResponseType(typeof(ErrorMessage), 500)]
        public async Task<IActionResult> GetAccountBalance([FromQuery] string idContaCorrente)
        {
            var resultContaCorrente = await _accountService.SearchAccount(idContaCorrente, "");

            var returnCC = resultContaCorrente.FirstOrDefault();

            if (returnCC.Numero == 0)
            {
                _logger.LogError(returnCC.MensagemErro);
                return BadRequest(returnCC.MensagemErro);
            }

            if (returnCC.Numero > 0 && returnCC.Ativo == 0)
            {
                _logger.LogError(returnCC.MensagemErro);
                return BadRequest(returnCC.MensagemErro);
            }

            var resultSaldoContaCorrente = await _accountService.GetAccountBalance(idContaCorrente, "");

            var returnTotalSaldoCC = resultSaldoContaCorrente.FirstOrDefault();

            if (returnTotalSaldoCC.NumeroConta == 0)
            {
                _logger.LogError("A conta n�o possui nenhuma movimenta��o o valor do saldo � 0.00");
                return BadRequest("A conta n�o possui nenhuma movimenta��o o valor do saldo � 0.00");
            }

            return Ok(resultSaldoContaCorrente);
        }
    }
}